
// --- Delivery Agent Onboarding Dashboard ---
import React, { useEffect, useState } from "react";
import {
  Button, Input, Checkbox, Dialog, DialogTrigger, DialogContent, DialogFooter, DialogHeader, DialogTitle, DialogDescription, Textarea, Select, SelectContent, SelectItem, SelectTrigger, SelectValue, Tabs, TabsList, TabsTrigger, TabsContent, Label, Table, TableHeader, TableBody, TableRow, TableCell, Card, CardContent, Switch
} from "@/components/ui";
import { CheckCircleIcon, ClockIcon, DownloadIcon, BellIcon, UploadIcon, PlusIcon, ThumbsUpIcon, ThumbsDownIcon, CalculatorIcon, XCircleIcon, FileTextIcon, SendIcon, MailIcon } from "lucide-react";

export default function AgentOnboardingDashboard() {
  const [agents, setAgents] = useState([]);
  const [statusFilter, setStatusFilter] = useState("all");
  const [hubFilter, setHubFilter] = useState("all");
  const [showForm, setShowForm] = useState(false);
  const [approvalModal, setApprovalModal] = useState({ open: false, agent: null, action: "" });
  const [actionNote, setActionNote] = useState("");
  const [newAgent, setNewAgent] = useState({ name: "", phone: "", email: "", region: "", rate_card: "", bank_account: "", upi_id: "", hub: "" });
  const [payouts, setPayouts] = useState([]);
  const [month, setMonth] = useState("");
  const [notification, setNotification] = useState(null);
  const [csvPreview, setCsvPreview] = useState([]);
  const [showPreview, setShowPreview] = useState(false);
  const [selectedPayouts, setSelectedPayouts] = useState([]);
  const [bulkNote, setBulkNote] = useState("");
  const [showBulkModal, setShowBulkModal] = useState(false);
  const [invoiceMode, setInvoiceMode] = useState(false);

  const fetchAllData = () => {
    fetch("/api/onboarding-agents")
      .then(res => res.json())
      .then(setAgents);

    fetch("/api/payouts-latest")
      .then(res => res.json())
      .then(setPayouts);
  };

  useEffect(() => {
    fetchAllData();
  }, []);

  const showToast = (message) => {
    setNotification(message);
    setTimeout(() => setNotification(null), 3000);
  };

  const handleCsvUpload = (file) => {
    const formData = new FormData();
    formData.append("csv", file);
    fetch("/api/upload-csv", {
      method: "POST",
      body: formData
    }).then(() => {
      showToast("CSV uploaded and data refreshed");
      fetchAllData();
    }).catch(() => showToast("Upload failed"));
  };

  const handleBulkApprove = () => {
    fetch("/api/payout-approve-bulk", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ casper_ids: selectedPayouts, note: bulkNote })
    }).then(() => {
      showToast("Bulk approvals submitted");
      setSelectedPayouts([]);
      setBulkNote("");
      setShowBulkModal(false);
    });
  };

  const handleBulkPayout = () => {
    fetch("/api/initiate-bulk-payout", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ casper_ids: selectedPayouts })
    }).then(res => res.json()).then(data => {
      showToast("Bulk payouts initiated");
    }).catch(() => showToast("Failed to initiate bulk payouts"));
  };

  const toggleSelectAll = () => {
    if (selectedPayouts.length === payouts.length) {
      setSelectedPayouts([]);
    } else {
      setSelectedPayouts(payouts.map(p => p.casper_id));
    }
  };

  const toggleSelectOne = (id) => {
    setSelectedPayouts(prev => prev.includes(id) ? prev.filter(i => i !== id) : [...prev, id]);
  };

  const handleDownloadSelectedInvoices = () => {
    fetch("/api/generate-invoices", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ casper_ids: selectedPayouts })
    })
      .then(res => res.blob())
      .then(blob => {
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement("a");
        a.href = url;
        a.download = "invoices.zip";
        document.body.appendChild(a);
        a.click();
        a.remove();
        window.URL.revokeObjectURL(url);
      });
  };

  const initiateBankPayout = (casperId) => {
    fetch("/api/initiate-bank-payout", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ casper_id: casperId })
    })
      .then(res => res.json())
      .then(data => {
        if (data.success) {
          showToast("Payout initiated successfully");
        } else {
          showToast("Failed to initiate payout");
        }
      })
      .catch(() => showToast("Error triggering payout"));
  };

  const handleDownloadInvoice = (casperId) => {
    fetch(`/api/generate-invoice/${casperId}`)
      .then(res => res.blob())
      .then(blob => {
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement("a");
        a.href = url;
        a.download = `${casperId}_invoice.pdf`;
        document.body.appendChild(a);
        a.click();
        a.remove();
        window.URL.revokeObjectURL(url);
      });
  };

  const totalPayout = payouts.reduce((sum, p) => sum + (p.final_payout || 0), 0);
  const totalTds = payouts.reduce((sum, p) => sum + (p.tds_amount || 0), 0);
  const hubWise = payouts.reduce((acc, p) => {
    acc[p.hub] = acc[p.hub] || { total: 0, count: 0 };
    acc[p.hub].total += p.final_payout || 0;
    acc[p.hub].count += 1;
    return acc;
  }, {});

  return <div>{/* Dashboard UI Here */}</div>;
}
